package backend;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

/* Tests unitaires de UrlAnalyzer */
class UrlAnalyzerTest {

    private UrlAnalyzer analyzer;

    @BeforeEach
    void setUp() {
        analyzer = new UrlAnalyzer();
    }

    //  Validation 

    @ParameterizedTest
    @NullAndEmptySource
    @ValueSource(strings = {"   ", "\t"})
    void emptyUrlIsNotVerified(String input) {
        UrlAnalysisResult r = analyzer.analyze(input);
        assertEquals(RiskLevel.NOT_VERIFIED, r.level());
    }

    @ParameterizedTest
    @ValueSource(strings = {
            "example.com",              // schéma manquant
            "ht!tp://example.com",      // syntaxe invalide
            "http://exa mple.com",      // espace
            "ftp://example.com",        // schéma non supporté
            "http://",                  // hôte manquant
            "http://localhost"          // pas de domaine valide
    })
    void malformedUrlIsNotVerifiedNeverSafe(String input) {
        UrlAnalysisResult r = analyzer.analyze(input);
        assertEquals(RiskLevel.NOT_VERIFIED, r.level());
        assertNotEquals(RiskLevel.LOW, r.level());
        assertFalse(r.reasons().isEmpty());
    }

    @Test
    void validUrlPassesValidation() {
        assertNull(analyzer.validate("https://www.example.com/page"));
    }

    // Règles de scoring

    @Test
    void cleanHttpsUrlIsLow() {
        UrlAnalysisResult r = analyzer.analyze("https://www.wikipedia.org");
        assertEquals(RiskLevel.LOW, r.level());
        assertEquals(0, r.score());
    }

    @Test
    void httpOnlyAddsPointsButStaysLow() {
        UrlAnalysisResult r = analyzer.analyze("http://www.example.com");
        assertEquals(UrlAnalyzer.POINTS_HTTP, r.score());
        assertEquals(RiskLevel.LOW, r.level());
    }

    @Test
    void ipHostIsMediumOrHigher() {
        UrlAnalysisResult r = analyzer.analyze("https://192.168.1.10/index");
        assertEquals(UrlAnalyzer.POINTS_IP_HOST, r.score());
        assertEquals(RiskLevel.MEDIUM, r.level());
    }

    @Test
    void httpPlusIpHostIsHigh() {
        UrlAnalysisResult r = analyzer.analyze("http://192.168.1.10/index");
        assertEquals(RiskLevel.HIGH, r.level());
    }

    @Test
    void misleadingSubdomainIsDetected() {
        UrlAnalysisResult r = analyzer.analyze("https://paypal.com.evil-site.xyz/");
        assertTrue(r.score() >= UrlAnalyzer.POINTS_BRAND_IN_SUBDOMAIN);
        assertTrue(r.reasons().stream().anyMatch(s -> s.contains("Sous-domaine trompeur")));
    }

    @Test
    void realBrandDomainIsNotFlaggedAsMisleading() {
        UrlAnalysisResult r = analyzer.analyze("https://www.paypal.com/");
        assertTrue(r.reasons().stream().noneMatch(s -> s.contains("Sous-domaine trompeur")));
        assertEquals(RiskLevel.LOW, r.level());
    }

    @Test
    void atSignInUrlIsDetected() {
        UrlAnalysisResult r = analyzer.analyze("https://www.google.com@evil.example.net/");
        assertTrue(r.reasons().stream().anyMatch(s -> s.contains("@")));
        assertTrue(r.score() >= UrlAnalyzer.POINTS_AT_SIGN);
    }

    @Test
    void suspiciousKeywordIsDetected() {
        UrlAnalysisResult r = analyzer.analyze("https://example.com/login/verify");
        assertEquals(UrlAnalyzer.POINTS_KEYWORDS, r.score());
        assertTrue(r.reasons().stream().anyMatch(s -> s.contains("Mot-clé suspect")));
    }

    @Test
    void suspiciousTldIsDetected() {
        UrlAnalysisResult r = analyzer.analyze("https://my-shop.xyz/");
        assertEquals(UrlAnalyzer.POINTS_SUSPICIOUS_TLD, r.score());
    }

    @Test
    void urlShortenerIsDetected() {
        UrlAnalysisResult r = analyzer.analyze("https://bit.ly/abc123");
        assertEquals(UrlAnalyzer.POINTS_SHORTENER, r.score());
    }

    @Test
    void oddPortIsDetected() {
        UrlAnalysisResult r = analyzer.analyze("https://www.example.com:8081/");
        assertEquals(UrlAnalyzer.POINTS_ODD_PORT, r.score());
    }

    @Test
    void combinedRulesGiveHigh() {
        UrlAnalysisResult r = analyzer.analyze("http://paypal.com.secure-login.tk/verify/account");
        assertEquals(RiskLevel.HIGH, r.level());
    }

    //  Mapping score -> risque
    @Test
    void riskMappingBoundaries() {
        assertEquals(RiskLevel.LOW, analyzer.mapToRisk(0));
        assertEquals(RiskLevel.LOW, analyzer.mapToRisk(UrlAnalyzer.MEDIUM_THRESHOLD - 1));
        assertEquals(RiskLevel.MEDIUM, analyzer.mapToRisk(UrlAnalyzer.MEDIUM_THRESHOLD));
        assertEquals(RiskLevel.MEDIUM, analyzer.mapToRisk(UrlAnalyzer.HIGH_THRESHOLD - 1));
        assertEquals(RiskLevel.HIGH, analyzer.mapToRisk(UrlAnalyzer.HIGH_THRESHOLD));
    }
}
