package backend;

import java.util.List;

/*
  Résultat de l'analyse d'une URL.
  C'est un "record"  : objet immuable, donc sûr à partager entre threads.
   @param url     l'URL analysée (telle que saisie)
   @param level   le niveau de risque
   @param score   le score cumulé des règles déclenchées
   @param reasons la liste des raisons (pour l'affichage dans l'interface)
 */
public record UrlAnalysisResult(String url, RiskLevel level, int score, List<String> reasons) {

    public UrlAnalysisResult {
        reasons = List.copyOf(reasons); // copie défensive donc la liste can't be modified */
    }
}
