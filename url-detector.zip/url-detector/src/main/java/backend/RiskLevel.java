package backend;

/*
 level de risque possibles pour une analyse.
  NOT_VERIFIED is used quand on ne peut pas conclure (URL invalide ou vide)
  on ne dit JAMAIS "LOW/Safe" pour un élément non vérifié.*/
public enum RiskLevel {
    LOW,
    MEDIUM,
    HIGH,
    NOT_VERIFIED
}