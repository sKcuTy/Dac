package backend;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/*
  Analyse une URL avec des règles locales (Option A du sujet) :
     1. validation du format,
     2. calcul d'un score cumulatif selon des règles,
     3. conversion du score en niveau de risque (LOW / MEDIUM / HIGH).
 
  La classe est SANS ÉTAT (aucun attribut modifiable) : plusieurs threads peuvent appeler analyze() en même temps sans risque (thread-safe).
   La méthode analyze() ne lève jamais d'exception.
 */
public class UrlAnalyzer {

    // Seuils de mapping score -> risque 
    static final int MEDIUM_THRESHOLD = 25;
    static final int HIGH_THRESHOLD = 50;

    //  Points attribués à chaque règle 
    static final int POINTS_HTTP = 15;
    static final int POINTS_IP_HOST = 40;
    static final int POINTS_AT_SIGN = 30;
    static final int POINTS_BRAND_IN_SUBDOMAIN = 30;
    static final int POINTS_PUNYCODE = 25;
    static final int POINTS_KEYWORDS = 15;
    static final int POINTS_SUSPICIOUS_TLD = 15;
    static final int POINTS_SHORTENER = 15;
    static final int POINTS_MANY_SUBDOMAINS = 15;
    static final int POINTS_LONG_URL = 10;
    static final int POINTS_MANY_HYPHENS = 10;
    static final int POINTS_ODD_PORT = 10;

    private static final int LONG_URL_LENGTH = 75;

    private static final Pattern IPV4 = Pattern.compile("^\\d{1,3}(\\.\\d{1,3}){3}$");

    private static final Set<String> SUSPICIOUS_KEYWORDS = Set.of(
            "login", "signin", "verify", "secure", "account", "update",
            "password", "confirm", "bank", "wallet");

    private static final Set<String> SUSPICIOUS_TLDS = Set.of(
            "tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "zip");

    private static final Set<String> SHORTENERS = Set.of(
            "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "cutt.ly");

    private static final Set<String> BRANDS = Set.of(
            "paypal", "google", "facebook", "apple", "microsoft",
            "amazon", "netflix", "instagram", "whatsapp");

    /* Analyse une URL et renvoie toujours un résultat (jamais d'exception) */
    public UrlAnalysisResult analyze(String rawUrl) {
        try {
            String error = validate(rawUrl);
            if (error != null) {
                // URL invalide : on ne peut pas conclure -> NOT_VERIFIED (pas de "safe")
                return new UrlAnalysisResult(rawUrl, RiskLevel.NOT_VERIFIED, 0, List.of(error));
            }
            return score(rawUrl.trim());
        } catch (RuntimeException e) {
            // Filet de sécurité : une erreur inattendue ne doit pas faire planter l'application
            return new UrlAnalysisResult(rawUrl, RiskLevel.NOT_VERIFIED, 0,
                    List.of("Erreur interne pendant l'analyse : " + e.getClass().getSimpleName()));
        }
    }

    
    // 1) VALIDATION
   

    /*  Vérifie que l'URL est bien formée.
      @return null si l'URL est valide, sinon un message d'erreur.
     */
    public String validate(String rawUrl) {
        if (rawUrl == null || rawUrl.isBlank()) {
            return "URL vide";
        }
        String url = rawUrl.trim();
        if (url.chars().anyMatch(Character::isWhitespace)) {
            return "URL mal formée : contient des espaces";
        }
        URI uri;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e) {
            return "URL mal formée : " + e.getReason();
        }
        String scheme = uri.getScheme();
        if (scheme == null) {
            return "URL mal formée : schéma manquant (http:// ou https://)";
        }
        if (!scheme.equalsIgnoreCase("http") && !scheme.equalsIgnoreCase("https")) {
            return "Schéma non supporté : " + scheme;
        }
        String host = uri.getHost();
        if (host == null || host.isEmpty()) {
            return "URL mal formée : nom d'hôte manquant ou invalide";
        }
        if (!isIpHost(host) && !host.contains(".")) {
            return "URL mal formée : nom de domaine invalide";
        }
        return null;
    }

   
    // 2) SCORING PAR RÈGLES
    

    private UrlAnalysisResult score(String url) {
        URI uri = URI.create(url); // sûr : l'URL a déjà été validée
        String host = uri.getHost().toLowerCase(Locale.ROOT);
        String fullLower = url.toLowerCase(Locale.ROOT);

        int score = 0;
        List<String> reasons = new ArrayList<>();

        // Règle:     HTTP au lieu de HTTPS
        if ("http".equalsIgnoreCase(uri.getScheme())) {
            score += POINTS_HTTP;
            reasons.add("Connexion non chiffrée (HTTP au lieu de HTTPS)");
        }

        // Règle:     hôte = adresse IP
        boolean ipHost = isIpHost(host);
        if (ipHost) {
            score += POINTS_IP_HOST;
            reasons.add("L'hôte est une adresse IP au lieu d'un nom de domaine");
        }

        // Règle : '@' dans l'URL (http://google.com@evil.com mène à evil.com)
        if (uri.getRawUserInfo() != null) {
            score += POINTS_AT_SIGN;
            reasons.add("Présence de '@' : la partie avant '@' cache le vrai site");
        }

        // Règle : punycode (caractères Unicode déguisés, ex. "pаypal" avec un 'а' cyrillique)
        if (host.contains("xn--")) {
            score += POINTS_PUNYCODE;
            reasons.add("Nom de domaine en punycode (risque d'homographe)");
        }

        // Règle : mots-clés suspects (login, verify, ...)
        String keyword = findKeyword(fullLower);
        if (keyword != null) {
            score += POINTS_KEYWORDS;
            reasons.add("Mot-clé suspect dans l'URL : \"" + keyword + "\"");
        }

        // Règles qui n'ont de sens que pour un vrai nom de domaine
        if (!ipHost) {
            String[] labels = host.split("\\.");
            String tld = labels[labels.length - 1];
            String registrable = labels.length >= 2
                    ? labels[labels.length - 2] + "." + tld
                    : host;

            // Règle : TLD souvent utilisé pour le phishing
            if (SUSPICIOUS_TLDS.contains(tld)) {
                score += POINTS_SUSPICIOUS_TLD;
                reasons.add("Extension de domaine suspecte : \"." + tld + "\"");
            }

            // Règle : raccourcisseur d'URL (destination cachée)
            if (SHORTENERS.contains(host)) {
                score += POINTS_SHORTENER;
                reasons.add("Lien raccourci : la destination réelle est cachée");
            }

            // Règle : trop de sous-domaines (ex. a.b.c.d.site.com)
            if (labels.length > 4) {
                score += POINTS_MANY_SUBDOMAINS;
                reasons.add("Trop de sous-domaines (" + (labels.length - 2) + ")");
            }

            // Règle : sous-domaine trompeur (paypal.com.evil.xyz)
            String brand = findMisleadingBrand(host, registrable);
            if (brand != null) {
                score += POINTS_BRAND_IN_SUBDOMAIN;
                reasons.add("Sous-domaine trompeur : \"" + brand
                        + "\" apparaît mais le vrai domaine est \"" + registrable + "\"");
            }

            // Règle : beaucoup de tirets dans le nom d'hôte
            if (host.chars().filter(c -> c == '-').count() >= 3) {
                score += POINTS_MANY_HYPHENS;
                reasons.add("Beaucoup de tirets dans le nom de domaine");
            }
        }

        // Règle : URL très longue
        if (url.length() > LONG_URL_LENGTH) {
            score += POINTS_LONG_URL;
            reasons.add("URL très longue (" + url.length() + " caractères)");
        }

        // Règle : port non standard
        int port = uri.getPort();
        if (port != -1 && port != 80 && port != 443) {
            score += POINTS_ODD_PORT;
            reasons.add("Port non standard : " + port);
        }

        if (reasons.isEmpty()) {
            reasons.add("Aucune règle suspecte déclenchée");
        }
        return new UrlAnalysisResult(url, mapToRisk(score), score, reasons);
    }

    
    // 3) MAPPING SCORE -> RISQUE
    

    /** Convertit un score cumulé en niveau de risque. */
    public RiskLevel mapToRisk(int score) {
        if (score >= HIGH_THRESHOLD) {
            return RiskLevel.HIGH;
        }
        if (score >= MEDIUM_THRESHOLD) {
            return RiskLevel.MEDIUM;
        }
        return RiskLevel.LOW;
    }

   
    // Méthodes utilitaires
   

    private boolean isIpHost(String host) {
        return host.startsWith("[") || IPV4.matcher(host).matches(); // IPv6 ou IPv4
    }

    private String findKeyword(String text) {
        for (String k : SUSPICIOUS_KEYWORDS) {
            if (text.contains(k)) {
                return k;
            }
        }
        return null;
    }

    /** Une marque connue est dans l'hôte mais PAS dans le vrai domaine (les 2 derniers labels). */
    private String findMisleadingBrand(String host, String registrable) {
        for (String b : BRANDS) {
            if (host.contains(b) && !registrable.contains(b)) {
                return b;
            }
        }
        return null;
    }
}
