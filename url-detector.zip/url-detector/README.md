# url-detector (partie 2 : analyse d'URL)

Module d'analyse du risque d'une URL (règles locales, score cumulatif).

## Prérequis
- JDK 17 ou plus
- Maven 3.8+
- VS Code avec « Extension Pack for Java »

## Commandes
```
mvn test      # lance les tests JUnit 5
mvn compile   # compile le projet
```

## Structure
```
src/main/java/backend/   RiskLevel, UrlAnalysisResult, UrlAnalyzer
src/test/java/backend/   UrlAnalyzerTest
```

## Utilisation
```java
UrlAnalyzer analyzer = new UrlAnalyzer();
UrlAnalysisResult r = analyzer.analyze("https://exemple.com");
r.level();    // LOW, MEDIUM, HIGH ou NOT_VERIFIED
r.score();    // score cumulé
r.reasons();  // liste des raisons
```
`UrlAnalyzer` n'a pas d'état : plusieurs threads peuvent l'utiliser en même temps.

## Travail en équipe
- Une branche par personne, puis une pull request vers `main`.
- Chaque membre ajoute ses classes dans son propre package sous `src/main/java/`.
- Ne jamais envoyer `target/` sur GitHub.
