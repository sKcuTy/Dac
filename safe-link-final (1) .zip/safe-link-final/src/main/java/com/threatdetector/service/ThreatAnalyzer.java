package com.threatdetector.service;

import com.threatdetector.model.ThreatResult;

/** Contrat commun des analyseurs (URL, message, futur : API en ligne, IA...). */
public interface ThreatAnalyzer {

    /** Doit être thread-safe et ne jamais lever d'exception. */
    ThreatResult analyze(String input);

    /** @return null si l'entrée est valide, sinon un message d'erreur lisible. */
    default String validate(String input) {
        return input == null || input.isBlank() ? "Input is empty." : null;
    }
}
