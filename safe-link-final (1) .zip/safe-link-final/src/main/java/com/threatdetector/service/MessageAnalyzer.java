package com.threatdetector.service;

import com.threatdetector.model.InputType;
import com.threatdetector.model.RiskLevel;
import com.threatdetector.model.ThreatResult;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Détection par règles locales sur le texte d'un message (email/SMS).
 * Les liens trouvés dans le message sont analysés par UrlAnalyzer.
 * Sans état -> thread-safe.
 */
public class MessageAnalyzer implements ThreatAnalyzer {

    private record Rule(Pattern pattern, int points, String reason) {
        Rule(String regex, int points, String reason) {
            this(Pattern.compile(regex, Pattern.CASE_INSENSITIVE), points, reason);
        }
    }

    private static final List<Rule> RULES = List.of(
            new Rule("\\b(urgent|immediately|act now|within 24 hours|last chance|asap)\\b", 15,
                    "Uses urgent or pressure wording."),
            new Rule("\\b(account (is |has been |was )?(blocked|suspended|locked|closed|restricted)"
                    + "|suspicious activity|will be (suspended|deleted|closed))\\b", 15,
                    "Threatens the loss or blocking of an account."),
            new Rule("\\b(password|credentials|verification code|login details|pin code|otp"
                    + "|confirm your identity)\\b", 25,
                    "Asks for a password, a code or credentials."),
            new Rule("\\b(bank account|credit card|card number|bank details|payment details|iban)\\b", 25,
                    "Asks for banking or payment information."),
            new Rule("\\b(you won|prize|congratulations|refund|claim your|free gift)\\b", 20,
                    "Promises a prize, a refund or a gift."),
            new Rule("\\b(click here|click the link|click this|verify your|confirm your|update your)\\b", 10,
                    "Asks you to click, verify or confirm something."),
            new Rule("\\b(weekly account digest|account digest|notification settings)\\b", 25,
                    "Mentions account digest or notification settings that should be checked carefully."));

   private static final Pattern LINK = Pattern.compile(
        "(?:\\b[^\\s:/]{1,20}://|www\\.)[^\\s<>\"']+",
        Pattern.CASE_INSENSITIVE
);
    private static final int POINTS_HAS_LINK = 5;

    private final UrlAnalyzer urlAnalyzer;

    public MessageAnalyzer(UrlAnalyzer urlAnalyzer) {
        this.urlAnalyzer = urlAnalyzer;
    }

    
@Override
public ThreatResult analyze(String message) {
    try {
        if (message == null || message.isBlank()) {
            return ThreatResult.notVerified(
                    message, InputType.MESSAGE, "Empty message."
            );
        }

        int score = 0;
        List<String> reasons = new ArrayList<>();

        // Track links that could not be verified
        boolean hasUnverifiedLink = false;

        for (Rule rule : RULES) {
            if (rule.pattern().matcher(message).find()) {
                score += rule.points();
                reasons.add(rule.reason());
            }
        }

        Set<String> links = extractLinks(message);

        if (!links.isEmpty()) {
            score += POINTS_HAS_LINK;
            reasons.add("Contains " + links.size() + " link(s).");

            for (String link : links) {
                String candidate = link.regionMatches(
                        true, 0, "www.", 0, 4
                ) ? "https://" + link : link;

                ThreatResult r = urlAnalyzer.analyze(candidate);

                if (r.isVerified()) {
                    score += r.score();

                    if (r.score() > 0) {
                        r.reasons().forEach(
                                x -> reasons.add("Link " + link + ": " + x)
                        );
                    }
                } else {
                    hasUnverifiedLink = true;
                    reasons.add(
                            "Link " + link + " could not be checked."
                    );
                }
            }
        }

        // Never classify a message with an unverified link as safe
        if (hasUnverifiedLink) {
            return ThreatResult.notVerified(
                    message,
                    InputType.MESSAGE,
                    "A link in this message could not be verified."
            );
        }

        score = Math.min(score, 100);

        if (reasons.isEmpty()) {
            reasons.add(
                    "No common warning signs found. This does not prove the message is safe."
            );
        }

        return new ThreatResult(
                message,
                InputType.MESSAGE,
                RiskLevel.fromScore(score),
                score,
                reasons
        );

    } catch (RuntimeException e) {
        return ThreatResult.notVerified(
                message,
                InputType.MESSAGE,
                "Internal error during analysis: "
                        + e.getClass().getSimpleName()
        );
    }
}


    static Set<String> extractLinks(String text) {
        Set<String> links = new LinkedHashSet<>();
        Matcher m = LINK.matcher(text);
        while (m.find()) {
            String link = m.group().replaceAll("[.,!?;:)\\]]+$", "");
            if (!link.isEmpty()) links.add(link);
        }
        return links;
    }
}
