package com.threatdetector.service;

import com.threatdetector.model.InputType;
import com.threatdetector.model.RiskLevel;
import com.threatdetector.model.ThreatResult;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Détection par règles locales (Option A) : validation, score cumulatif, niveau.
 * Sans état -> thread-safe. analyze() ne lève jamais d'exception.
 */
public class UrlAnalyzer implements ThreatAnalyzer {

    static final int POINTS_HTTP = 25;
    static final int POINTS_IP_HOST = 40;
    static final int POINTS_AT_SIGN = 30;
    static final int POINTS_BRAND_IN_SUBDOMAIN = 30;
    static final int POINTS_PUNYCODE = 25;
    static final int POINTS_KEYWORDS = 15;
    static final int POINTS_SUSPICIOUS_TLD = 15;
    static final int POINTS_SHORTENER = 15;
    static final int POINTS_MANY_SUBDOMAINS = 15;
    static final int POINTS_LONG_URL = 10;
    static final int POINTS_MANY_HYPHENS = 10;
    static final int POINTS_ODD_PORT = 10;
    private static final int LONG_URL_LENGTH = 75;

    private static final Pattern IPV4 = Pattern.compile("^\\d{1,3}(\\.\\d{1,3}){3}$");
    private static final Set<String> KEYWORDS = Set.of("login", "signin", "verify", "secure",
            "account", "update", "password", "confirm", "bank", "wallet", "security", "portal");
    private static final Set<String> SUSPICIOUS_TLDS = Set.of("tk", "ml", "ga", "cf", "gq",
            "xyz", "top", "click", "zip");
    private static final Set<String> SHORTENERS = Set.of("bit.ly", "tinyurl.com", "t.co",
            "goo.gl", "ow.ly", "is.gd", "cutt.ly");
    private static final Set<String> BRANDS = Set.of("paypal", "google", "facebook", "apple",
            "microsoft", "amazon", "netflix", "instagram", "whatsapp");

    @Override
    public ThreatResult analyze(String rawUrl) {
        try {
            String error = validate(rawUrl);
            if (error != null) {
                return ThreatResult.notVerified(rawUrl, InputType.URL, error);
            }
            return score(rawUrl.trim());
        } catch (RuntimeException e) {
            return ThreatResult.notVerified(rawUrl, InputType.URL,
                    "Internal error during analysis: " + e.getClass().getSimpleName());
        }
    }

    @Override
    public String validate(String rawUrl) {
        if (rawUrl == null || rawUrl.isBlank()) return "Empty URL.";
        String url = rawUrl.trim();
        if (url.chars().anyMatch(Character::isWhitespace)) return "Malformed URL: contains spaces.";
        URI uri;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e) {
            return "Malformed URL: " + e.getReason() + ".";
        }
        String scheme = uri.getScheme();
        if (scheme == null) return "Malformed URL: missing scheme (http:// or https://).";
        if (!scheme.equalsIgnoreCase("http") && !scheme.equalsIgnoreCase("https")) {
            return "Unsupported scheme: " + scheme + ".";
        }
        String host = uri.getHost();
        if (host == null || host.isEmpty()) return "Malformed URL: missing or invalid host name.";
        if (!isIpHost(host) && !host.contains(".")) return "Malformed URL: invalid domain name.";
        return null;
    }

    private ThreatResult score(String url) {
        URI uri = URI.create(url); // sûr : déjà validée
        String host = uri.getHost().toLowerCase(Locale.ROOT);
        String lower = url.toLowerCase(Locale.ROOT);
        int score = 0;
        List<String> reasons = new ArrayList<>();

        if ("http".equalsIgnoreCase(uri.getScheme())) {
            score += POINTS_HTTP;
            reasons.add("Unencrypted connection (HTTP instead of HTTPS).");
        }
        boolean ipHost = isIpHost(host);
        if (ipHost) {
            score += POINTS_IP_HOST;
            reasons.add("The host is an IP address instead of a domain name.");
        }
        if (uri.getRawUserInfo() != null) {
            score += POINTS_AT_SIGN;
            reasons.add("Contains '@': the part before it hides the real destination.");
        }
        if (host.contains("xn--")) {
            score += POINTS_PUNYCODE;
            reasons.add("Punycode domain (possible look-alike characters).");
        }
        List<String> matchedKeywords = KEYWORDS.stream().sorted()
                .filter(lower::contains).toList();
        if (!matchedKeywords.isEmpty()) {
            // Count each distinct warning keyword instead of stopping at the first match.
            int keywordPoints = Math.min(matchedKeywords.size(), 3) * POINTS_KEYWORDS;
            score += keywordPoints;
            reasons.add("Suspicious keyword(s) in the URL: " + String.join(", ", matchedKeywords) + ".");
        }
        if (!ipHost) {
            String[] labels = host.split("\\.");
            String tld = labels[labels.length - 1];
            String registrable = labels.length >= 2 ? labels[labels.length - 2] + "." + tld : host;

            if (SUSPICIOUS_TLDS.contains(tld)) {
                score += POINTS_SUSPICIOUS_TLD;
                reasons.add("Domain extension often used for phishing: \"." + tld + "\".");
            }
            if (SHORTENERS.contains(host)) {
                score += POINTS_SHORTENER;
                reasons.add("Shortened link: the real destination is hidden.");
            }
            if (labels.length > 4) {
                score += POINTS_MANY_SUBDOMAINS;
                reasons.add("Too many subdomains (" + (labels.length - 2) + ").");
            }
            String brand = BRANDS.stream().sorted()
                    .filter(b -> host.contains(b) && !registrable.contains(b)).findFirst().orElse(null);
            if (brand != null) {
                score += POINTS_BRAND_IN_SUBDOMAIN;
                reasons.add("Misleading domain: \"" + brand + "\" appears but the real domain is \""
                        + registrable + "\".");
            }
            if (host.chars().filter(c -> c == '-').count() >= 3) {
                score += POINTS_MANY_HYPHENS;
                reasons.add("Many hyphens in the domain name.");
            }
        }
        if (url.length() > LONG_URL_LENGTH) {
            score += POINTS_LONG_URL;
            reasons.add("Very long URL (" + url.length() + " characters).");
        }
        int port = uri.getPort();
        if (port != -1 && port != 80 && port != 443) {
            score += POINTS_ODD_PORT;
            reasons.add("Non-standard port: " + port + ".");
        }
        if (reasons.isEmpty()) {
            reasons.add("No common warning signs found. This does not prove the link is safe.");
        }
        return new ThreatResult(url, InputType.URL, RiskLevel.fromScore(score), score, reasons);
    }

    private static boolean isIpHost(String host) {
        return host.startsWith("[") || IPV4.matcher(host).matches();
    }
}
