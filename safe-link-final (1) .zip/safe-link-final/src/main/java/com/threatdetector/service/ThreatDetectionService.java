package com.threatdetector.service;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.InputType;
import com.threatdetector.model.ThreatResult;

/**
 * Point d'entrée unique du backend : choisit l'analyseur selon le type d'entrée.
 * analyze() ne lève jamais d'exception ; en cas de problème -> NOT_VERIFIED (jamais "safe").
 */
public class ThreatDetectionService {

    private final ThreatAnalyzer urlAnalyzer;
    private final ThreatAnalyzer messageAnalyzer;

    public ThreatDetectionService(ThreatAnalyzer urlAnalyzer, ThreatAnalyzer messageAnalyzer) {
        this.urlAnalyzer = urlAnalyzer;
        this.messageAnalyzer = messageAnalyzer;
    }

    public ThreatResult analyze(AnalysisRequest request) {
        if (request == null) {
            return ThreatResult.notVerified("", null, "Missing request.");
        }
        String input = request.input();
        InputType type = request.type();
        if (type == null) {
            return ThreatResult.notVerified(input, null, "Missing input type.");
        }
        if (input == null || input.isBlank()) {
            return ThreatResult.notVerified(input, type, "Input is empty.");
        }
        try {
            ThreatResult result = (type == InputType.URL ? urlAnalyzer : messageAnalyzer).analyze(input);
            return result != null ? result
                    : ThreatResult.notVerified(input, type, "The analyzer returned no result.");
        } catch (Exception e) {
            return ThreatResult.notVerified(input, type, "Analysis error: "
                    + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
        }
    }

    /** @return null si valide, sinon le message d'erreur à afficher. */
    public String validate(InputType type, String input) {
        return (type == InputType.URL ? urlAnalyzer : messageAnalyzer).validate(input);
    }
}
