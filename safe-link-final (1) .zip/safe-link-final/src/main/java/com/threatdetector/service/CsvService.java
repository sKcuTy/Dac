package com.threatdetector.service;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.InputType;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Lecture d'un fichier CSV "type,input" (type = URL ou MESSAGE).
 * Gère : fichier manquant/vide, en-tête invalide, lignes invalides, guillemets non fermés,
 * champs entre guillemets contenant virgules ou retours à la ligne.
 * Les lignes invalides ne font pas échouer l'import : elles sont renvoyées avec une erreur.
 */
public class CsvService {

    /** Une ligne du CSV : soit une requête valide, soit une erreur. */
    public record CsvRow(int line, String raw, AnalysisRequest request, String error) {
        public boolean isValid() { return request != null; }
    }

    private static final Set<String> TYPE_HEADERS = Set.of("type", "kind", "input_type");
    private static final Set<String> VALUE_HEADERS = Set.of("input", "content", "value", "text");

    public List<CsvRow> read(Path file) throws IOException {
        if (file == null || !Files.isRegularFile(file)) {
            throw new FileNotFoundException("CSV file not found: " + file);
        }
        String text;
        try {
            text = Files.readString(file, StandardCharsets.UTF_8);
        } catch (java.nio.charset.CharacterCodingException e) {
            throw new IOException("The file is not valid UTF-8 text.", e);
        }
        return parse(text);
    }

    /** Public pour pouvoir tester sans fichier. */
    public List<CsvRow> parse(String text) throws IOException {
        if (text.startsWith("\uFEFF")) text = text.substring(1);

        List<Record> records = split(text);
        if (records.isEmpty()) {
            throw new IOException("The CSV file is empty.");
        }

        int typeIndex = 0;
        int inputIndex = 1;
        int start = 0;
        List<String> first = records.get(0).fields;

        // Accept both the simple format (type,input) and the professor's
        // dataset format (id,input_type,content,expected_...).
        int detectedType = findHeaderIndex(first, TYPE_HEADERS);
        int detectedInput = findHeaderIndex(first, VALUE_HEADERS);
        if (records.get(0).error == null && (detectedType >= 0 || detectedInput >= 0)) {
            if (detectedType < 0 || detectedInput < 0) {
                throw new IOException("Invalid CSV header. It must contain input_type/type and content/input columns.");
            }
            typeIndex = detectedType;
            inputIndex = detectedInput;
            start = 1;
        }

        List<CsvRow> rows = new ArrayList<>();
        for (int i = start; i < records.size(); i++) {
            Record r = records.get(i);
            if (r.error != null) {
                rows.add(new CsvRow(r.line, r.raw, null, r.error));
                continue;
            }
            if (r.fields.size() <= Math.max(typeIndex, inputIndex)) {
                rows.add(new CsvRow(r.line, r.raw, null,
                        "Missing required CSV columns (input_type and content)."));
                continue;
            }

            String typeValue = r.fields.get(typeIndex).trim();
            String input = r.fields.get(inputIndex).trim();
            String typeText = typeValue.toLowerCase();
            InputType type = switch (typeText) {
                case "url", "link" -> InputType.URL;
                case "message", "msg" -> InputType.MESSAGE;
                default -> null;
            };
            if (type == null) {
                rows.add(new CsvRow(r.line, r.raw, null,
                        "Type must be URL or MESSAGE (got \"" + typeValue + "\")."));
            } else if (input.isEmpty()) {
                rows.add(new CsvRow(r.line, r.raw, null, "Empty input."));
            } else {
                rows.add(new CsvRow(r.line, r.raw, new AnalysisRequest(input, type), null));
            }
        }
        return rows;
    }

    private static int findHeaderIndex(List<String> fields, Set<String> accepted) {
        for (int i = 0; i < fields.size(); i++) {
            if (accepted.contains(fields.get(i).trim().toLowerCase())) return i;
        }
        return -1;
    }

    // ---- découpage en enregistrements (gère les guillemets) ----

    private static final class Record {
        int line;
        String raw;
        List<String> fields = new ArrayList<>();
        String error;
    }

    private static List<Record> split(String text) {
        List<Record> out = new ArrayList<>();
        int n = text.length();
        int i = 0, line = 1;
        while (i < n) {
            int startIdx = i, startLine = line;
            StringBuilder cur = new StringBuilder();
            Record rec = new Record();
            rec.line = startLine;
            boolean quoted = false;
            boolean blank = true;
            while (i < n) {
                char c = text.charAt(i);
                if (quoted) {
                    if (c == '"') {
                        if (i + 1 < n && text.charAt(i + 1) == '"') { cur.append('"'); i++; }
                        else quoted = false;
                    } else {
                        if (c == '\n') line++;
                        cur.append(c);
                    }
                } else if (c == '"') {
                    quoted = true; blank = false;
                } else if (c == ',') {
                    rec.fields.add(cur.toString()); cur.setLength(0); blank = false;
                } else if (c == '\n' || c == '\r') {
                    if (c == '\r' && i + 1 < n && text.charAt(i + 1) == '\n') i++;
                    line++; i++;
                    break;
                } else {
                    if (!Character.isWhitespace(c)) blank = false;
                    cur.append(c);
                }
                i++;
            }
            rec.fields.add(cur.toString());
            rec.raw = text.substring(startIdx, Math.min(i, n)).strip();
            if (quoted) rec.error = "Unclosed quotation marks.";
            if (!blank || rec.error != null) out.add(rec);
        }
        return out;
    }
}
