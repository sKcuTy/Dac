package com.threatdetector.concurrency;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.ThreatResult;
import com.threatdetector.service.ThreatDetectionService;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Exécute un lot d'analyses en parallèle sur un pool de threads de taille fixe.
 * Indépendant de l'interface : les callbacks sont remis via 'callbackExecutor'
 * (JavaFX : Platform::runLater ; tests : Runnable::run).
 */
public class AnalysisManager implements AutoCloseable {

    private final ExecutorService workers;
    private final Executor callbackExecutor;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public AnalysisManager(int threadCount, Executor callbackExecutor) {
        if (threadCount < 1) throw new IllegalArgumentException("threadCount must be at least 1");
        if (callbackExecutor == null) throw new IllegalArgumentException("callbackExecutor is required");
        this.callbackExecutor = callbackExecutor;
        AtomicInteger counter = new AtomicInteger(1);
        this.workers = Executors.newFixedThreadPool(threadCount, task -> {
            Thread t = new Thread(task, "analysis-worker-" + counter.getAndIncrement());
            t.setDaemon(true); // ne bloque pas la fermeture de l'application
            return t;
        });
    }

    public boolean isRunning() { return running.get(); }

    /** Lance le lot et rend la main immédiatement. Un seul lot à la fois. */
    public void analyzeAll(List<AnalysisRequest> requests, ThreatDetectionService service,
                           AnalysisListener listener) {
        if (requests == null || service == null || listener == null) {
            throw new IllegalArgumentException("requests, service and listener are required");
        }
        if (!running.compareAndSet(false, true)) {
            throw new IllegalStateException("An analysis batch is already running.");
        }
        List<AnalysisRequest> batch = new ArrayList<>(requests);
        int total = batch.size();
        if (total == 0) {
            running.set(false);
            post(() -> { listener.onProgress(0, 0); listener.onFinished(); });
            return;
        }

        Object lock = new Object();
        int[] completed = {0};
        try {
            for (int i = 0; i < total; i++) {
                final int index = i;
                final AnalysisRequest request = batch.get(i);
                workers.execute(() -> {
                    post(() -> listener.onStarted(index, request));
                    ThreatResult result;
                    try {
                        result = service.analyze(request);
                    } catch (Throwable t) { // une tâche qui échoue n'est jamais "safe"
                        result = ThreatResult.notVerified(request == null ? "" : request.input(),
                                request == null ? null : request.type(), "Unexpected failure: " + t);
                    }
                    final ThreatResult finalResult = result;
                    // Bloc synchronisé : garantit l'ordre résultat -> progression -> fin
                    synchronized (lock) {
                        int done = ++completed[0];
                        post(() -> listener.onResult(index, finalResult));
                        post(() -> listener.onProgress(done, total));
                        if (done == total) {
                            running.set(false);
                            post(listener::onFinished);
                        }
                    }
                });
            }
        } catch (RejectedExecutionException e) {
            running.set(false);
            throw new IllegalStateException("The analysis manager is closed.", e);
        }
    }

    private void post(Runnable r) {
        try {
            callbackExecutor.execute(r);
        } catch (RuntimeException ignored) {
            // l'interface est peut-être déjà fermée
        }
    }

    @Override
    public void close() {
        workers.shutdown();
        try {
            if (!workers.awaitTermination(2, TimeUnit.SECONDS)) workers.shutdownNow();
        } catch (InterruptedException e) {
            workers.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
