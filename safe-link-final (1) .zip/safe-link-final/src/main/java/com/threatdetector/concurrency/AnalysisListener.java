package com.threatdetector.concurrency;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.ThreatResult;

/** Callbacks d'un lot d'analyses. 'index' = position de la requête dans la liste soumise. */
public interface AnalysisListener {
    default void onStarted(int index, AnalysisRequest request) { }
    default void onResult(int index, ThreatResult result) { }
    default void onProgress(int completed, int total) { }
    default void onFinished() { }
}
