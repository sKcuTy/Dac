package com.threatdetector.model;

/** Niveaux de risque. NOT_VERIFIED = analyse impossible : ce n'est JAMAIS "sûr". */
public enum RiskLevel {
    LOW("Low"), MEDIUM("Medium"), HIGH("High"), NOT_VERIFIED("Not verified");

    /** Seuils communs à tous les analyseurs (score cumulé -> niveau). */
    public static final int MEDIUM_THRESHOLD = 25;
    public static final int HIGH_THRESHOLD = 50;

    private final String label;

    RiskLevel(String label) { this.label = label; }

    public String label() { return label; }

    /** Convertit un score cumulé (0-100) en niveau LOW / MEDIUM / HIGH. */
    public static RiskLevel fromScore(int score) {
        if (score >= HIGH_THRESHOLD) return HIGH;
        if (score >= MEDIUM_THRESHOLD) return MEDIUM;
        return LOW;
    }
}
