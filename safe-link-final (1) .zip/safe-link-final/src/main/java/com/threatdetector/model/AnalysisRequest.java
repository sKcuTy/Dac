package com.threatdetector.model;

/** Une entrée à analyser (immuable, donc partageable entre threads). */
public record AnalysisRequest(String input, InputType type) { }
