package com.threatdetector.model;

public enum InputType { URL, MESSAGE }
