package com.threatdetector.model;

import java.util.List;

/**
 * Résultat d'une analyse (immuable, thread-safe).
 * Règle du sujet : une analyse échouée est NOT_VERIFIED, jamais LOW/"safe".
 */
public record ThreatResult(String input, InputType type, RiskLevel riskLevel,
                           int score, List<String> reasons) {

    public ThreatResult {
        input = input == null ? "" : input;
        riskLevel = riskLevel == null ? RiskLevel.NOT_VERIFIED : riskLevel;
        score = riskLevel == RiskLevel.NOT_VERIFIED ? 0 : Math.max(0, Math.min(100, score));
        reasons = reasons == null ? List.of() : List.copyOf(reasons);
    }

    public static ThreatResult notVerified(String input, InputType type, String reason) {
        return new ThreatResult(input, type, RiskLevel.NOT_VERIFIED, 0,
                List.of(reason == null || reason.isBlank()
                        ? "The analysis could not be completed." : reason));
    }

    public boolean isVerified() { return riskLevel != RiskLevel.NOT_VERIFIED; }
}
