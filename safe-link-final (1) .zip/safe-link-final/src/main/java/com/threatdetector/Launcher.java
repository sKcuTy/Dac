package com.threatdetector;

import com.threatdetector.ui.App;

/**
 * Point d'entrée à utiliser (bouton "Run" de VS Code ou mvn javafx:run).
 * Une classe qui n'étend PAS Application évite l'erreur
 * "JavaFX runtime components are missing" au lancement depuis le classpath.
 */
public final class Launcher {
    private Launcher() { }

    public static void main(String[] args) {
        App.main(args);
    }
}
