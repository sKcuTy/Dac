package com.threatdetector.ui;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.InputType;
import com.threatdetector.model.ThreatResult;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;

/** Une ligne du tableau : l'entrée, son état et son résultat (propriétés observables). */
final class ResultRow {

    enum Status {
        WAITING("Waiting"), CHECKING("Checking"), DONE("Done"), NOT_VERIFIED("Not verified");

        private final String label;
        Status(String label) { this.label = label; }
        String label() { return label; }
    }

    private final String input;
    private final AnalysisRequest request; // null si la ligne CSV était invalide
    private final ObjectProperty<Status> status = new SimpleObjectProperty<>(Status.WAITING);
    private final ObjectProperty<ThreatResult> result = new SimpleObjectProperty<>();

    ResultRow(AnalysisRequest request) {
        this.request = request;
        this.input = request.input();
    }

    private ResultRow(String rawInput) {
        this.request = null;
        this.input = rawInput;
    }

    /** Ligne CSV rejetée : affichée directement en "Not verified" avec la raison. */
    static ResultRow rejected(String rawInput, String reason) {
        ResultRow row = new ResultRow(rawInput == null ? "" : rawInput);
        row.setResult(ThreatResult.notVerified(row.input, null, reason));
        return row;
    }

    String input() { return input; }
    AnalysisRequest request() { return request; }
    InputType type() { return request == null ? null : request.type(); }
    ObjectProperty<Status> statusProperty() { return status; }
    ObjectProperty<ThreatResult> resultProperty() { return result; }
    ThreatResult result() { return result.get(); }
    Status status() { return status.get(); }

    void reset() { result.set(null); status.set(Status.WAITING); }
    void markChecking() { status.set(Status.CHECKING); }

    void setResult(ThreatResult r) {
        result.set(r);
        status.set(r.isVerified() ? Status.DONE : Status.NOT_VERIFIED);
    }
}
