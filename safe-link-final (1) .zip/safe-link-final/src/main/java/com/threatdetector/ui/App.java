package com.threatdetector.ui;

import com.threatdetector.concurrency.AnalysisManager;
import com.threatdetector.service.MessageAnalyzer;
import com.threatdetector.service.ThreatAnalyzer;
import com.threatdetector.service.ThreatDetectionService;
import com.threatdetector.service.UrlAnalyzer;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.InputStream;
import java.net.URL;

/** Assemble le backend et l'interface JavaFX. */
public class App extends Application {

    private static final int WORKER_THREADS = 4;
    private AnalysisManager manager;

    @Override
    public void start(Stage stage) {
        // Délai artificiel (ms) par analyse pour que les indicateurs de progression soient visibles
        // avec des règles locales quasi instantanées. Désactiver : -Dthreat.delay=0
        long delay = Long.getLong("threat.delay", 400L);

        UrlAnalyzer urlRules = new UrlAnalyzer();
        MessageAnalyzer messageRules = new MessageAnalyzer(urlRules);
        ThreatAnalyzer urlAnalyzer = delay > 0 ? new DemoDelayAnalyzer(urlRules, delay) : urlRules;
        ThreatAnalyzer messageAnalyzer = delay > 0 ? new DemoDelayAnalyzer(messageRules, delay) : messageRules;

        ThreatDetectionService service = new ThreatDetectionService(urlAnalyzer, messageAnalyzer);
        manager = new AnalysisManager(WORKER_THREADS, Platform::runLater);

        MainWindow window = new MainWindow(stage, service, manager);
        Scene scene = new Scene(window.build(), 1100, 760);
        URL css = getClass().getResource("/css/style.css");
        if (css != null) scene.getStylesheets().add(css.toExternalForm());

        try (InputStream icon = getClass().getResourceAsStream("/images/logo.png")) {
            if (icon != null) stage.getIcons().add(new Image(icon));
        } catch (Exception ignored) {
            // icône facultative
        }
        stage.setTitle("Safe Link - Threat Detection");
        stage.setMinWidth(900);
        stage.setMinHeight(640);
        stage.setScene(scene);
        stage.show();
    }

    @Override
    public void stop() {
        if (manager != null) manager.close();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
