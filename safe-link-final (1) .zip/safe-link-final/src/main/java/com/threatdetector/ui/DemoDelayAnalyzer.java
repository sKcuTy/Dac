package com.threatdetector.ui;

import com.threatdetector.model.ThreatResult;
import com.threatdetector.service.ThreatAnalyzer;

import java.util.concurrent.ThreadLocalRandom;

/** Décorateur de démonstration : ajoute une courte attente avant l'analyse réelle. */
final class DemoDelayAnalyzer implements ThreatAnalyzer {

    private final ThreatAnalyzer delegate;
    private final long baseMillis;

    DemoDelayAnalyzer(ThreatAnalyzer delegate, long baseMillis) {
        this.delegate = delegate;
        this.baseMillis = baseMillis;
    }

    @Override
    public ThreatResult analyze(String input) {
        try {
            Thread.sleep(baseMillis / 2 + ThreadLocalRandom.current().nextLong(baseMillis + 1));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return delegate.analyze(input);
    }

    @Override
    public String validate(String input) {
        return delegate.validate(input);
    }
}
