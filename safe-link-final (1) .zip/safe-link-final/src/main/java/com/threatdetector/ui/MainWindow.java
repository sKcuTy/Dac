package com.threatdetector.ui;

import com.threatdetector.concurrency.AnalysisListener;
import com.threatdetector.concurrency.AnalysisManager;
import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.InputType;
import com.threatdetector.model.RiskLevel;
import com.threatdetector.model.ThreatResult;
import com.threatdetector.service.CsvService;
import com.threatdetector.service.CsvService.CsvRow;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Vue principale (JavaFX). Ne contient AUCUNE règle de détection ni de parsing CSV :
 * tout passe par ThreatDetectionService, CsvService et AnalysisManager.
 */
final class MainWindow {

    private static final String EXAMPLE_URL = "http://secure-login.example.com@192.0.2.10:8080/verify";
    private static final String EXAMPLE_MESSAGE =
            "URGENT: Your account will be suspended. Verify your password now at " + EXAMPLE_URL;

    private final Stage stage;
    private final com.threatdetector.service.ThreatDetectionService service;
    private final AnalysisManager manager;
    private final CsvService csvService = new CsvService();

    private final ObservableList<ResultRow> rows = FXCollections.observableArrayList();
    private final TableView<ResultRow> table = new TableView<>(rows);

    private final ToggleGroup modeGroup = new ToggleGroup();
    private final ToggleButton urlToggle = new ToggleButton("URL");
    private final ToggleButton messageToggle = new ToggleButton("Message");
    private final Label entryLabel = new Label("Enter a URL");
    private final TextArea entry = new TextArea();
    private final Label errorLabel = new Label();
    private final Label feedbackLabel = new Label();
    private final Button addButton = new Button("Add");
    private final Button exampleButton = new Button("Example");
    private final Button browseButton = new Button("Browse CSV...");
    private final Button analyzeButton = new Button("Analyze all");
    private final Button clearButton = new Button("Clear");
    private final ProgressBar progressBar = new ProgressBar(0);
    private final Label percentLabel = new Label("0%");
    private final Label statusLabel = new Label("Ready");
    private final TextArea details = new TextArea();
    private final Label totalLabel = new Label();
    private final Label lowLabel = new Label();
    private final Label mediumLabel = new Label();
    private final Label highLabel = new Label();
    private final Label notVerifiedLabel = new Label();

    private boolean busy;

    MainWindow(Stage stage, com.threatdetector.service.ThreatDetectionService service,
               AnalysisManager manager) {
        this.stage = stage;
        this.service = service;
        this.manager = manager;
    }

    Parent build() {
        BorderPane root = new BorderPane();
        root.setTop(buildHeader());

        VBox center = new VBox(14, buildInputCard(), buildResultsCard());
        center.setPadding(new Insets(16, 24, 8, 24));
        root.setCenter(center);
        root.setBottom(buildBottomBar());

        updateModeTexts();
        refreshStats();
        return root;
    }

    // ------------------------------------------------------------------ construction UI

    private Parent buildHeader() {
        HBox header = new HBox(14);
        header.getStyleClass().add("header");
        header.setAlignment(Pos.CENTER_LEFT);
        try (InputStream in = getClass().getResourceAsStream("/images/logo.png")) {
            if (in != null) {
                ImageView logo = new ImageView(new Image(in));
                logo.setFitHeight(44);
                logo.setPreserveRatio(true);
                header.getChildren().add(logo);
            }
        } catch (IOException ignored) {
            // logo facultatif
        }
        Label title = new Label("Threat Assessment Desk");
        title.getStyleClass().add("title");
        Label subtitle = new Label("Check links and messages for phishing signs. "
                + "Anything that cannot be verified is never reported as safe.");
        subtitle.getStyleClass().add("muted");
        header.getChildren().add(new VBox(2, title, subtitle));
        return header;
    }

    private Parent buildInputCard() {
        urlToggle.setToggleGroup(modeGroup);
        messageToggle.setToggleGroup(modeGroup);
        urlToggle.setSelected(true);
        modeGroup.selectedToggleProperty().addListener((obs, old, now) -> {
            if (now == null) old.setSelected(true); // toujours un mode actif
            else { updateModeTexts(); showError(""); }
        });

        entry.setWrapText(true);
        entry.setPrefRowCount(3);
        entry.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER && !e.isShiftDown() && urlToggle.isSelected()) {
                e.consume();
                addFromEntry();
            }
        });

        addButton.getStyleClass().add("primary");
        addButton.setOnAction(e -> addFromEntry());
        exampleButton.setOnAction(e -> {
            entry.setText(urlToggle.isSelected() ? EXAMPLE_URL : EXAMPLE_MESSAGE);
            entry.requestFocus();
        });
        browseButton.setOnAction(e -> browseCsv());

        errorLabel.getStyleClass().add("error");
        feedbackLabel.setWrapText(true);

        HBox modes = new HBox(0, urlToggle, messageToggle);
        HBox actions = new HBox(10, addButton, exampleButton, new Region(), browseButton);
        HBox.setHgrow(actions.getChildren().get(2), Priority.ALWAYS);
        actions.setAlignment(Pos.CENTER_LEFT);

        VBox card = new VBox(8, sectionTitle("1. Add inputs"), modes, entryLabel, entry, actions,
                errorLabel, feedbackLabel);
        card.getStyleClass().add("card");
        return card;
    }

    private Parent buildResultsCard() {
        table.setPlaceholder(new Label("No input yet. Add a URL or a message, or load a CSV file."));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.getColumns().add(this.<String>column("Input", 3.0, cd -> new ReadOnlyStringWrapper(cd.getValue().input())));
        table.getColumns().add(this.<String>column("Type", 0.9, cd -> new ReadOnlyStringWrapper(
                cd.getValue().type() == null ? "?" : cd.getValue().type().name())));
        table.getColumns().add(statusColumn());
        table.getColumns().add(riskColumn());
        table.getColumns().add(scoreColumn());
        table.getColumns().add(summaryColumn());
        VBox.setVgrow(table, Priority.ALWAYS);
        table.getSelectionModel().selectedItemProperty().addListener((obs, old, now) -> showDetails(now));

        details.setEditable(false);
        details.setWrapText(true);
        details.setPrefRowCount(5);
        details.setPromptText("Select a row to see why it got this result.");

        HBox stats = new HBox(18, totalLabel, lowLabel, mediumLabel, highLabel, notVerifiedLabel);
        stats.setAlignment(Pos.CENTER_LEFT);
        lowLabel.getStyleClass().add("risk-low");
        mediumLabel.getStyleClass().add("risk-medium");
        highLabel.getStyleClass().add("risk-high");
        notVerifiedLabel.getStyleClass().add("risk-nv");

        VBox card = new VBox(8, sectionTitle("2. Results"), stats, table, details);
        card.getStyleClass().add("card");
        VBox.setVgrow(card, Priority.ALWAYS);
        return card;
    }

    private Parent buildBottomBar() {
        analyzeButton.getStyleClass().add("primary");
        analyzeButton.setOnAction(e -> analyzeAll());
        clearButton.setOnAction(e -> clearAll());
        progressBar.setPrefWidth(260);
        HBox.setHgrow(statusLabel, Priority.ALWAYS);
        statusLabel.setMaxWidth(Double.MAX_VALUE);
        HBox bar = new HBox(12, analyzeButton, clearButton, progressBar, percentLabel, statusLabel);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(10, 24, 14, 24));
        bar.getStyleClass().add("bottom-bar");
        return bar;
    }

    private static Label sectionTitle(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("section-title");
        return l;
    }

    private <T> TableColumn<ResultRow, T> column(String title, double weight,
            javafx.util.Callback<TableColumn.CellDataFeatures<ResultRow, T>,
                    javafx.beans.value.ObservableValue<T>> factory) {
        TableColumn<ResultRow, T> col = new TableColumn<>(title);
        col.setCellValueFactory(factory);
        col.setMaxWidth(Integer.MAX_VALUE * weight);
        return col;
    }

    private TableColumn<ResultRow, ResultRow.Status> statusColumn() {
        TableColumn<ResultRow, ResultRow.Status> col =
                this.<ResultRow.Status>column("Status", 1.4, cd -> cd.getValue().statusProperty());
        col.setCellFactory(c -> new TableCell<>() {
            @Override
            protected void updateItem(ResultRow.Status item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else if (item == ResultRow.Status.CHECKING) {
                    ProgressIndicator spinner = new ProgressIndicator();
                    spinner.setPrefSize(16, 16);
                    setGraphic(spinner);
                    setText(item.label());
                } else {
                    setGraphic(null);
                    setText(item.label());
                }
            }
        });
        return col;
    }

    private TableColumn<ResultRow, ThreatResult> riskColumn() {
        TableColumn<ResultRow, ThreatResult> col =
                this.<ThreatResult>column("Risk", 1.0, cd -> cd.getValue().resultProperty());
        col.setCellFactory(c -> new TableCell<>() {
            @Override
            protected void updateItem(ThreatResult item, boolean empty) {
                super.updateItem(item, empty);
                getStyleClass().removeAll("risk-low", "risk-medium", "risk-high", "risk-nv");
                if (empty) {
                    setText(null);
                } else if (item == null || !item.isVerified()) {
                    setText("\u2014");
                } else {
                    setText(item.riskLevel().label());
                    getStyleClass().add(riskStyle(item.riskLevel()));
                }
            }
        });
        return col;
    }

    private TableColumn<ResultRow, ThreatResult> scoreColumn() {
        TableColumn<ResultRow, ThreatResult> col =
                this.<ThreatResult>column("Score", 0.9, cd -> cd.getValue().resultProperty());
        col.setCellFactory(c -> new TableCell<>() {
            @Override
            protected void updateItem(ThreatResult item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) setText(null);
                else setText(item == null || !item.isVerified() ? "\u2014" : item.score() + " / 100");
            }
        });
        return col;
    }

    private TableColumn<ResultRow, ThreatResult> summaryColumn() {
        TableColumn<ResultRow, ThreatResult> col =
                this.<ThreatResult>column("Why", 3.0, cd -> cd.getValue().resultProperty());
        col.setCellFactory(c -> new TableCell<>() {
            @Override
            protected void updateItem(ThreatResult item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else if (item == null) {
                    setText("Not analyzed yet.");
                } else {
                    List<String> r = item.reasons();
                    setText(r.isEmpty() ? "" : r.get(0) + (r.size() > 1 ? " (+" + (r.size() - 1) + " more)" : ""));
                }
            }
        });
        return col;
    }

    private static String riskStyle(RiskLevel level) {
        return switch (level) {
            case LOW -> "risk-low";
            case MEDIUM -> "risk-medium";
            case HIGH -> "risk-high";
            case NOT_VERIFIED -> "risk-nv";
        };
    }

    // ------------------------------------------------------------------ actions

    private void updateModeTexts() {
        boolean url = urlToggle.isSelected();
        entryLabel.setText(url ? "Enter a URL (Enter to add)" : "Paste a message");
        entry.setPromptText(url ? "https://example.com/account" : "Paste the message text here...");
        entry.setPrefRowCount(url ? 2 : 5);
    }

private void addFromEntry() {
    if (busy) return;

    InputType type = urlToggle.isSelected()
            ? InputType.URL
            : InputType.MESSAGE;

    String raw = entry.getText() == null
            ? ""
            : entry.getText().trim();

    if (raw.isEmpty()) {
        showError("Please enter a URL or a message first.");
        return;
    }

    // Validate messages only.
    // Malformed URLs must reach UrlAnalyzer and return NOT_VERIFIED.
    if (type == InputType.MESSAGE) {
        String problem = service.validate(type, raw);

        if (problem != null) {
            showError(problem);
            return;
        }
    }

    rows.add(new ResultRow(new AnalysisRequest(raw, type)));

    entry.clear();
    showError("");
    statusLabel.setText("Added 1 item");
    refreshStats();
}

   

    private void browseCsv() {
        if (busy) return;
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Choose a CSV file (type,input or input_type,content)");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV files", "*.csv"));
        File file = chooser.showOpenDialog(stage);
        if (file == null) return;
        loadCsv(file);
    }

    private void loadCsv(File file) {
        feedbackLabel.getStyleClass().removeAll("feedback-ok", "feedback-bad");
        try {
            List<CsvRow> parsed = csvService.read(file.toPath());
            int loaded = 0;
            int rejected = 0;
            for (CsvRow row : parsed) {
                if (row.isValid()) {
                    rows.add(new ResultRow(row.request()));
                    loaded++;
                } else {
                    rows.add(ResultRow.rejected(row.raw(), "Line " + row.line() + ": " + row.error()));
                    rejected++;
                }
            }
            feedbackLabel.setText(file.getName() + ": " + loaded + " loaded, " + rejected + " rejected"
                    + (parsed.isEmpty() ? " (no data rows found)" : ""));
            feedbackLabel.getStyleClass().add(loaded == 0 ? "feedback-bad" : "feedback-ok");
            statusLabel.setText(loaded > 0 ? "Loaded " + loaded + " item(s) from " + file.getName()
                    : "No items loaded");
        } catch (IOException e) {
            feedbackLabel.setText(file.getName() + ": not loaded. " + e.getMessage());
            feedbackLabel.getStyleClass().add("feedback-bad");
        } catch (RuntimeException e) {
            feedbackLabel.setText(file.getName() + ": unexpected error (" + e.getClass().getSimpleName() + ").");
            feedbackLabel.getStyleClass().add("feedback-bad");
        }
        refreshStats();
    }

    private void analyzeAll() {
        if (busy) return;
        List<ResultRow> batchRows = new ArrayList<>();
        List<AnalysisRequest> requests = new ArrayList<>();
        for (ResultRow row : rows) {
            if (row.request() != null) { // les lignes CSV rejetées sont déjà "Not verified"
                batchRows.add(row);
                requests.add(row.request());
            }
        }
        if (requests.isEmpty()) {
            statusLabel.setText("Nothing to analyze.");
            return;
        }
        batchRows.forEach(ResultRow::reset);
        setBusy(true);
        updateProgress(0, requests.size());
        statusLabel.setText("Analyzing " + requests.size() + " item(s)...");
        refreshStats();

        try {
            manager.analyzeAll(requests, service, new AnalysisListener() {
                @Override
                public void onStarted(int index, AnalysisRequest request) {
                    batchRows.get(index).markChecking();
                }

                @Override
                public void onResult(int index, ThreatResult result) {
                    ResultRow row = batchRows.get(index);
                    row.setResult(result);
                    if (row == table.getSelectionModel().getSelectedItem()) showDetails(row);
                    refreshStats();
                }

                @Override
                public void onProgress(int completed, int total) {
                    updateProgress(completed, total);
                    statusLabel.setText("Checked " + completed + " of " + total);
                }

                @Override
                public void onFinished() {
                    setBusy(false);
                    statusLabel.setText("All items analyzed");
                }
            });
        } catch (RuntimeException e) {
            setBusy(false);
            statusLabel.setText("Could not start the analysis: " + e.getMessage());
        }
    }

    private void clearAll() {
        if (busy) return;
        rows.clear();
        details.clear();
        feedbackLabel.setText("");
        showError("");
        updateProgress(0, 0);
        statusLabel.setText("Ready");
        refreshStats();
    }

    // ------------------------------------------------------------------ affichage

    private void setBusy(boolean value) {
        busy = value;
        analyzeButton.setDisable(value);
        clearButton.setDisable(value);
        addButton.setDisable(value);
        browseButton.setDisable(value);
        urlToggle.setDisable(value);
        messageToggle.setDisable(value);
    }

    private void updateProgress(int completed, int total) {
        double fraction = total == 0 ? 0 : (double) completed / total;
        progressBar.setProgress(fraction);
        percentLabel.setText(Math.round(fraction * 100) + "%");
    }

    private void showError(String message) {
        errorLabel.setText(message);
    }

    private void refreshStats() {
        int low = 0, medium = 0, high = 0, notVerified = 0;
        for (ResultRow row : rows) {
            ThreatResult r = row.result();
            if (r == null) continue;
            switch (r.riskLevel()) {
                case LOW -> low++;
                case MEDIUM -> medium++;
                case HIGH -> high++;
                case NOT_VERIFIED -> notVerified++;
            }
        }
        totalLabel.setText("Total: " + rows.size());
        lowLabel.setText("Low: " + low);
        mediumLabel.setText("Medium: " + medium);
        highLabel.setText("High: " + high);
        notVerifiedLabel.setText("Not verified: " + notVerified);
        analyzeButton.setDisable(busy || rows.isEmpty());
    }

    private void showDetails(ResultRow row) {
        if (row == null) {
            details.clear();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Input: ").append(row.input()).append("\n");
        ThreatResult r = row.result();
        if (r == null) {
            sb.append("Status: ").append(row.status().label()).append("\nNot analyzed yet.");
        } else {
            sb.append("Risk: ").append(r.riskLevel().label());
            if (r.isVerified()) sb.append("   Score: ").append(r.score()).append(" / 100");
            sb.append("\n\nWhy:\n");
            r.reasons().forEach(reason -> sb.append(" - ").append(reason).append("\n"));
        }
        details.setText(sb.toString());
    }
}
