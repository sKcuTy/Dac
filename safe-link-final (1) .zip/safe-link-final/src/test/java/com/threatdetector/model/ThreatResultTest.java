package com.threatdetector.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import org.junit.jupiter.api.Test;

class ThreatResultTest {

    @Test
    void notVerifiedIsNeverLowAndHasZeroScore() {
        ThreatResult r = ThreatResult.notVerified("x", InputType.URL, "boom");
        assertEquals(RiskLevel.NOT_VERIFIED, r.riskLevel());
        assertEquals(0, r.score());
        assertFalse(r.isVerified());
    }

    @Test
    void nullRiskLevelBecomesNotVerified() {
        assertEquals(RiskLevel.NOT_VERIFIED,
                new ThreatResult("x", InputType.URL, null, 50, List.of()).riskLevel());
    }

    @Test
    void scoreIsClamped() {
        assertEquals(100, new ThreatResult("x", InputType.URL, RiskLevel.HIGH, 250, List.of()).score());
    }
}
