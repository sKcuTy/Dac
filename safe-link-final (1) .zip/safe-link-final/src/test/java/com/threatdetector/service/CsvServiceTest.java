package com.threatdetector.service;

import static org.junit.jupiter.api.Assertions.*;

import com.threatdetector.model.InputType;
import com.threatdetector.service.CsvService.CsvRow;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;

class CsvServiceTest {

    private final CsvService csv = new CsvService();

    @Test
    void readsValidRowsAndReportsInvalidOnes() throws IOException {
        List<CsvRow> rows = csv.parse("type,input\r\n"
                + "URL,https://example.com\r\n"
                + "MESSAGE,\"Hello, world\"\r\n"
                + "UNKNOWN,something\r\n"
                + "MESSAGE,\r\n"
                + "URL\r\n");
        assertEquals(5, rows.size());
        assertTrue(rows.get(0).isValid());
        assertEquals(InputType.URL, rows.get(0).request().type());
        assertEquals("Hello, world", rows.get(1).request().input());
        assertFalse(rows.get(2).isValid());
        assertEquals(4, rows.get(2).line());
        assertFalse(rows.get(3).isValid());
        assertFalse(rows.get(4).isValid());
    }

    @Test
    void quotedFieldMayContainNewlineAndEscapedQuotes() throws IOException {
        List<CsvRow> rows = csv.parse("type,input\nMESSAGE,\"line1\nline2 \"\"quoted\"\"\"\nURL,http://a.bc\n");
        assertEquals(2, rows.size());
        assertEquals("line1\nline2 \"quoted\"", rows.get(0).request().input());
        assertEquals(4, rows.get(1).line());
    }

    @Test
    void unclosedQuoteIsReportedNotThrown() throws IOException {
        List<CsvRow> rows = csv.parse("type,input\nMESSAGE,\"oops\nURL,http://a.bc\n");
        assertEquals(1, rows.size());
        assertFalse(rows.get(0).isValid());
    }

    @Test
    void fileWithoutHeaderIsAccepted() throws IOException {
        assertEquals(1, csv.parse("URL,https://example.com\n").size());
    }

    @Test
    void badHeaderEmptyAndMissingFilesThrowIoException() throws IOException {
        assertThrows(IOException.class, () -> csv.parse("type,wrong\nURL,x\n"));
        assertThrows(IOException.class, () -> csv.parse("\n  \n"));
        assertThrows(FileNotFoundException.class, () -> csv.read(Path.of("does-not-exist.csv")));
        assertThrows(FileNotFoundException.class, () -> csv.read(null));
    }

    @Test
    void readsUtf8FileWithBom() throws IOException {
        Path f = Files.createTempFile("threat", ".csv");
        try {
            Files.writeString(f, "\uFEFFtype,input\nMESSAGE,caf\u00e9\n");
            List<CsvRow> rows = csv.read(f);
            assertEquals("caf\u00e9", rows.get(0).request().input());
        } finally {
            Files.deleteIfExists(f);
        }
    }

  
@Test
void readsProfessorDatasetFormatAndIgnoresExtraColumns() throws IOException {
    List<CsvRow> rows = csv.parse(
            "id,input_type,content,expected_risk_level,expected_category,triggered_rules_description\n"
            + "1,URL,https://www.example.edu/courses/cs302,Low,Legitimate,HTTPS website\n"
            + "2,URL,http://192.168.1.50/portal/update,High,IP,HTTP and IP host\n"
            + "6,MESSAGE,Your lab appointment is confirmed for tomorrow at 2:00 PM. Reply 1 to confirm.,Low,Normal,Appointment\n"
            + "10,MESSAGE,,Not Verified,Empty,Empty message\n"
    );

    assertEquals(4, rows.size());
    assertTrue(rows.get(0).isValid());
    assertEquals(InputType.URL, rows.get(0).request().type());
    assertEquals("https://www.example.edu/courses/cs302",
            rows.get(0).request().input());

    assertTrue(rows.get(1).isValid());
    assertEquals(InputType.MESSAGE, rows.get(2).request().type());
    assertFalse(rows.get(3).isValid());
    assertEquals("Empty input.", rows.get(3).error());
}

}
