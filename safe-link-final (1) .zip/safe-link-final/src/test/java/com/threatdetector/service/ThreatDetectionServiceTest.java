package com.threatdetector.service;

import static org.junit.jupiter.api.Assertions.*;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.InputType;
import com.threatdetector.model.RiskLevel;
import com.threatdetector.model.ThreatResult;
import org.junit.jupiter.api.Test;

class ThreatDetectionServiceTest {

    private final UrlAnalyzer url = new UrlAnalyzer();
    private final ThreatDetectionService service =
            new ThreatDetectionService(url, new MessageAnalyzer(url));

    @Test
    void dispatchesByType() {
        assertEquals(InputType.URL, service.analyze(new AnalysisRequest("https://example.com", InputType.URL)).type());
        assertEquals(InputType.MESSAGE, service.analyze(new AnalysisRequest("hello", InputType.MESSAGE)).type());
    }

    @Test
    void invalidRequestsAreNotVerified() {
        assertEquals(RiskLevel.NOT_VERIFIED, service.analyze(null).riskLevel());
        assertEquals(RiskLevel.NOT_VERIFIED, service.analyze(new AnalysisRequest("x", null)).riskLevel());
        assertEquals(RiskLevel.NOT_VERIFIED, service.analyze(new AnalysisRequest(" ", InputType.URL)).riskLevel());
    }

    @Test
    void crashingAnalyzerIsNeverReportedSafe() {
        ThreatAnalyzer broken = in -> { throw new IllegalStateException("boom"); };
        ThreatDetectionService s = new ThreatDetectionService(broken, broken);
        ThreatResult r = s.analyze(new AnalysisRequest("https://example.com", InputType.URL));
        assertEquals(RiskLevel.NOT_VERIFIED, r.riskLevel());
        assertTrue(r.reasons().get(0).contains("boom"));
    }
}
