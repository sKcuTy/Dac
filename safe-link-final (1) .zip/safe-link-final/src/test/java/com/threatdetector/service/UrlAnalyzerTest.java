package com.threatdetector.service;

import static org.junit.jupiter.api.Assertions.*;

import com.threatdetector.model.RiskLevel;
import com.threatdetector.model.ThreatResult;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UrlAnalyzerTest {

    private UrlAnalyzer analyzer;

    @BeforeEach
    void setUp() { analyzer = new UrlAnalyzer(); }

    @Test
    void emptyOrNullUrlIsNotVerified() {
        for (String s : new String[] {null, "", "   ", "\t"}) {
            assertEquals(RiskLevel.NOT_VERIFIED, analyzer.analyze(s).riskLevel());
        }
    }

    @Test
    void malformedUrlIsNotVerifiedNeverSafe() {
        List<String> bad = List.of("example.com", "ht!tp://example.com", "http://exa mple.com",
                "ftp://example.com", "http://", "http://localhost");
        for (String s : bad) {
            ThreatResult r = analyzer.analyze(s);
            assertEquals(RiskLevel.NOT_VERIFIED, r.riskLevel(), s);
            assertFalse(r.reasons().isEmpty(), s);
        }
    }

    @Test
    void cleanHttpsUrlIsLow() {
        ThreatResult r = analyzer.analyze("https://www.wikipedia.org");
        assertEquals(RiskLevel.LOW, r.riskLevel());
        assertEquals(0, r.score());
    }

    @Test
    void httpAloneIsMediumForTheReferenceDataset() {
        ThreatResult r = analyzer.analyze("http://www.example.com");
        assertEquals(UrlAnalyzer.POINTS_HTTP, r.score());
        assertEquals(RiskLevel.MEDIUM, r.riskLevel());
    }

    @Test
    void ipHostIsMedium() {
        ThreatResult r = analyzer.analyze("https://192.168.1.10/index");
        assertEquals(UrlAnalyzer.POINTS_IP_HOST, r.score());
        assertEquals(RiskLevel.MEDIUM, r.riskLevel());
    }

    @Test
    void httpPlusIpHostIsHigh() {
        assertEquals(RiskLevel.HIGH, analyzer.analyze("http://192.168.1.10/index").riskLevel());
    }

    @Test
    void misleadingSubdomainIsDetected() {
        ThreatResult r = analyzer.analyze("https://paypal.com.evil-site.xyz/");
        assertTrue(r.score() >= UrlAnalyzer.POINTS_BRAND_IN_SUBDOMAIN);
        assertTrue(r.reasons().stream().anyMatch(s -> s.contains("Misleading domain")));
    }

    @Test
    void realBrandDomainIsNotFlagged() {
        ThreatResult r = analyzer.analyze("https://www.paypal.com/");
        assertTrue(r.reasons().stream().noneMatch(s -> s.contains("Misleading domain")));
        assertEquals(RiskLevel.LOW, r.riskLevel());
    }

    @Test
    void atSignIsDetected() {
        ThreatResult r = analyzer.analyze("https://www.google.com@evil.example.net/");
        assertTrue(r.score() >= UrlAnalyzer.POINTS_AT_SIGN);
    }

    @Test
    void singleRulesGiveExpectedPoints() {
        assertEquals(2 * UrlAnalyzer.POINTS_KEYWORDS,
                analyzer.analyze("https://example.com/login/verify").score());
        assertEquals(UrlAnalyzer.POINTS_SUSPICIOUS_TLD, analyzer.analyze("https://my-shop.xyz/").score());
        assertEquals(UrlAnalyzer.POINTS_SHORTENER, analyzer.analyze("https://bit.ly/abc123").score());
        assertEquals(UrlAnalyzer.POINTS_ODD_PORT, analyzer.analyze("https://www.example.com:8081/").score());
    }

    @Test
    void combinedRulesGiveHigh() {
        assertEquals(RiskLevel.HIGH,
                analyzer.analyze("http://paypal.com.secure-login.tk/verify/account").riskLevel());
    }

    @Test
    void riskMappingBoundaries() {
        assertEquals(RiskLevel.LOW, RiskLevel.fromScore(RiskLevel.MEDIUM_THRESHOLD - 1));
        assertEquals(RiskLevel.MEDIUM, RiskLevel.fromScore(RiskLevel.MEDIUM_THRESHOLD));
        assertEquals(RiskLevel.MEDIUM, RiskLevel.fromScore(RiskLevel.HIGH_THRESHOLD - 1));
        assertEquals(RiskLevel.HIGH, RiskLevel.fromScore(RiskLevel.HIGH_THRESHOLD));
    }
}
