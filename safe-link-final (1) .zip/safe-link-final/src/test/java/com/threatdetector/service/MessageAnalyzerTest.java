package com.threatdetector.service;

import static org.junit.jupiter.api.Assertions.*;

import com.threatdetector.model.RiskLevel;
import com.threatdetector.model.ThreatResult;
import org.junit.jupiter.api.Test;

class MessageAnalyzerTest {

    private final MessageAnalyzer analyzer = new MessageAnalyzer(new UrlAnalyzer());

    @Test
    void emptyMessageIsNotVerified() {
        assertEquals(RiskLevel.NOT_VERIFIED, analyzer.analyze(null).riskLevel());
        assertEquals(RiskLevel.NOT_VERIFIED, analyzer.analyze("   ").riskLevel());
    }

    @Test
    void harmlessMessageIsLow() {
        ThreatResult r = analyzer.analyze("Hello, how are you today?");
        assertEquals(RiskLevel.LOW, r.riskLevel());
        assertEquals(0, r.score());
    }

    @Test
    void phishingMessageIsHigh() {
        ThreatResult r = analyzer.analyze("URGENT! Your account is blocked. Enter your password immediately.");
        assertEquals(RiskLevel.HIGH, r.riskLevel());
    }

    @Test
    void prizeMessageWithClickIsMedium() {
        ThreatResult r = analyzer.analyze("You won a prize! Click this link now.");
        assertEquals(RiskLevel.MEDIUM, r.riskLevel());
    }

    @Test
    void accountDigestMessageIsMediumForReferenceDataset() {
        ThreatResult r = analyzer.analyze("Please review your weekly account digest and notification settings.");
        assertEquals(RiskLevel.MEDIUM, r.riskLevel());
        assertEquals(25, r.score());
    }

    @Test
    void linksInsideMessageAreAnalyzed() {
        ThreatResult r = analyzer.analyze("Check http://192.168.1.10/login now");
        assertTrue(r.score() >= 40);
        assertTrue(r.reasons().stream().anyMatch(s -> s.startsWith("Link http://192.168.1.10/login")));
    }

    @Test
    void trailingPunctuationIsNotPartOfTheLink() {
        assertTrue(MessageAnalyzer.extractLinks("Go to https://example.com/page.").contains("https://example.com/page"));
    }

    @Test
    void scoreIsCappedAt100() {
        ThreatResult r = analyzer.analyze("URGENT account suspended password bank account you won prize "
                + "click here http://192.168.1.1/login/verify");
        assertEquals(100, r.score());
        assertEquals(RiskLevel.HIGH, r.riskLevel());
    }
    @Test
void messageWithUnverifiableLinkIsNotVerified() {
    ThreatResult r = analyzer.analyze(
            "Please check this link: http://invalid_url_format.com/test"
    );

    assertEquals(RiskLevel.NOT_VERIFIED, r.riskLevel());
}
@Test
void malformedLinkInsideMessageIsNotVerified() {
    ThreatResult r = analyzer.analyze(
            "Please check this link: ht!tp://invalid_url_format.com/test"
    );

    assertEquals(RiskLevel.NOT_VERIFIED, r.riskLevel());
}
}
