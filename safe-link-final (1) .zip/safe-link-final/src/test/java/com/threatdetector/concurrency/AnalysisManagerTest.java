package com.threatdetector.concurrency;

import static org.junit.jupiter.api.Assertions.*;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.InputType;
import com.threatdetector.model.RiskLevel;
import com.threatdetector.model.ThreatResult;
import com.threatdetector.service.MessageAnalyzer;
import com.threatdetector.service.ThreatAnalyzer;
import com.threatdetector.service.ThreatDetectionService;
import com.threatdetector.service.UrlAnalyzer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.Test;

class AnalysisManagerTest {

    private static class Recorder implements AnalysisListener {
        final List<ThreatResult> results = Collections.synchronizedList(new ArrayList<>());
        final List<Integer> indexes = Collections.synchronizedList(new ArrayList<>());
        final List<Integer> progress = Collections.synchronizedList(new ArrayList<>());
        final Set<Integer> started = Collections.synchronizedSet(new java.util.HashSet<>());
        final CountDownLatch finished = new CountDownLatch(1);
        volatile boolean resultAfterFinish;

        public void onStarted(int i, AnalysisRequest r) { started.add(i); }
        public void onResult(int i, ThreatResult r) {
            if (finished.getCount() == 0) resultAfterFinish = true;
            indexes.add(i); results.add(r);
        }
        public void onProgress(int c, int t) { progress.add(c); }
        public void onFinished() { finished.countDown(); }
    }

    private final UrlAnalyzer url = new UrlAnalyzer();

    @Test
    void analyzesAllRequestsInParallelAndReportsProgress() throws Exception {
        ThreatDetectionService service = new ThreatDetectionService(url, new MessageAnalyzer(url));
        List<AnalysisRequest> requests = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            requests.add(new AnalysisRequest(i % 2 == 0 ? "https://example" + i + ".com" : "hello " + i,
                    i % 2 == 0 ? InputType.URL : InputType.MESSAGE));
        }
        Recorder rec = new Recorder();
        try (AnalysisManager manager = new AnalysisManager(4, Runnable::run)) {
            manager.analyzeAll(requests, service, rec);
            assertTrue(rec.finished.await(5, TimeUnit.SECONDS));
            assertEquals(50, rec.results.size());
            assertEquals(50, Set.copyOf(rec.indexes).size());
            assertEquals(50, rec.started.size());
            assertEquals(50, rec.progress.get(rec.progress.size() - 1));
            assertFalse(rec.resultAfterFinish);
            assertFalse(manager.isRunning());
        }
    }

    @Test
    void emptyBatchFinishesImmediately() throws Exception {
        Recorder rec = new Recorder();
        try (AnalysisManager manager = new AnalysisManager(2, Runnable::run)) {
            manager.analyzeAll(List.of(), new ThreatDetectionService(url, url), rec);
            assertTrue(rec.finished.await(1, TimeUnit.SECONDS));
        }
    }

    @Test
    void secondBatchWhileRunningIsRejected() throws Exception {
        CountDownLatch release = new CountDownLatch(1);
        ThreatAnalyzer slow = in -> {
            try { release.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            return ThreatResult.notVerified(in, InputType.URL, "slow");
        };
        Recorder rec = new Recorder();
        try (AnalysisManager manager = new AnalysisManager(1, Runnable::run)) {
            List<AnalysisRequest> one = List.of(new AnalysisRequest("https://a.bc", InputType.URL));
            manager.analyzeAll(one, new ThreatDetectionService(slow, slow), rec);
            assertThrows(IllegalStateException.class,
                    () -> manager.analyzeAll(one, new ThreatDetectionService(slow, slow), new Recorder()));
            release.countDown();
            assertTrue(rec.finished.await(5, TimeUnit.SECONDS));
        }
    }

    @Test
    void failingTaskIsNotVerifiedAndBatchStillFinishes() throws Exception {
        ThreatDetectionService exploding = new ThreatDetectionService(url, url) {
            @Override
            public ThreatResult analyze(AnalysisRequest r) { throw new Error("fatal"); }
        };
        Recorder rec = new Recorder();
        try (AnalysisManager manager = new AnalysisManager(2, Runnable::run)) {
            manager.analyzeAll(List.of(new AnalysisRequest("https://a.bc", InputType.URL)), exploding, rec);
            assertTrue(rec.finished.await(5, TimeUnit.SECONDS));
            assertEquals(RiskLevel.NOT_VERIFIED, rec.results.get(0).riskLevel());
        }
    }

    @Test
    void invalidThreadCountIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new AnalysisManager(0, Runnable::run));
    }
    @Test
void provesThatFourTasksRunInParallel() throws Exception {

    CountDownLatch workersStarted = new CountDownLatch(4);
    CountDownLatch releaseWorkers = new CountDownLatch(1);

    ThreatAnalyzer blockingAnalyzer = in -> {
        workersStarted.countDown();

        try {
            releaseWorkers.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return ThreatResult.notVerified(
                in, InputType.URL, "Parallel test"
        );
    };

    ThreatDetectionService service =
            new ThreatDetectionService(blockingAnalyzer, blockingAnalyzer);

    List<AnalysisRequest> requests = new ArrayList<>();

    for (int i = 0; i < 4; i++) {
        requests.add(new AnalysisRequest(
                "https://example" + i + ".com",
                InputType.URL
        ));
    }

    Recorder rec = new Recorder();

    try (AnalysisManager manager =
                 new AnalysisManager(4, Runnable::run)) {

        manager.analyzeAll(requests, service, rec);

        boolean parallel = workersStarted.await(2, TimeUnit.SECONDS);

        releaseWorkers.countDown();

        assertTrue(parallel,
                "Four workers should start before any worker is released");

        assertTrue(rec.finished.await(5, TimeUnit.SECONDS));

        assertEquals(4, rec.results.size());
    } finally {
        releaseWorkers.countDown();
    }
}
}
