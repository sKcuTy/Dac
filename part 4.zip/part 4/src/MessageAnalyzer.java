
package com.threatdetector.service;

import com.threatdetector.model.*;

public class MessageAnalyzer {

    public ThreatResult analyze(String message) {

        if (message == null || message.trim().isEmpty()) {
            return ThreatResult.notVerified(
                message, InputType.MESSAGE, "Message vide"
            );
        }

        return new ThreatResult(
            message,
            InputType.MESSAGE,
            RiskLevel.MEDIUM,
            25,
            "Test Message effectué",
            "Completed"
        );
    }
}
