package com.threatdetector.model;

public enum RiskLevel {
    LOW, MEDIUM, HIGH, NOT_VERIFIED
}
