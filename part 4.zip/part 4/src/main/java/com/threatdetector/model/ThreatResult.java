package com.threatdetector.model;

public class ThreatResult {
    private final String input;
    private final InputType inputType;
    private final RiskLevel riskLevel;
    private final int score;
    private final String details;
    private final String status;

    public ThreatResult(String input, InputType inputType, RiskLevel riskLevel,
                        int score, String details, String status) {
        this.input = input;
        this.inputType = inputType;
        this.riskLevel = riskLevel;
        this.score = score;
        this.details = details;
        this.status = status;
    }

    public static ThreatResult notVerified(String input, InputType type, String reason) {
        return new ThreatResult(input, type, RiskLevel.NOT_VERIFIED, 0,
                reason == null ? "Analysis could not be completed." : reason,
                "Not Verified");
    }

    public String getInput() { return input; }
    public InputType getInputType() { return inputType; }
    public RiskLevel getRiskLevel() { return riskLevel; }
    public int getScore() { return score; }
    public String getDetails() { return details; }
    public String getStatus() { return status; }

    @Override
    public String toString() {
        return "ThreatResult{" +
                "input='" + input + '\'' +
                ", inputType=" + inputType +
                ", riskLevel=" + riskLevel +
                ", score=" + score +
                ", status='" + status + '\'' +
                '}';
    }
}
