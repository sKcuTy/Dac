package com.threatdetector.model;

public class AnalysisRequest {
    private final String input;
    private final InputType inputType;

    public AnalysisRequest(String input, InputType inputType) {
        this.input = input;
        this.inputType = inputType;
    }

    public String getInput() { return input; }
    public InputType getInputType() { return inputType; }
}
