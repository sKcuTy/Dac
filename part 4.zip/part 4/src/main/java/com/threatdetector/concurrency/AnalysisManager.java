package com.threatdetector.concurrency;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.ThreatResult;
import com.threatdetector.service.ThreatDetectionService;

import javax.swing.SwingUtilities;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/**
 * Runs analyses concurrently on a fixed-size thread pool.
 * UI callbacks are always dispatched on Swing's Event Dispatch Thread (EDT).
 */
public class AnalysisManager implements AutoCloseable {
    private final ExecutorService workers;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public AnalysisManager(int threadCount) {
        if (threadCount < 1) {
            throw new IllegalArgumentException("threadCount must be at least 1");
        }
        this.workers = Executors.newFixedThreadPool(threadCount);
    }

    public boolean isRunning() {
        return running.get();
    }

    public void analyzeAll(List<AnalysisRequest> requests,
                           ThreatDetectionService service,
                           Consumer<ThreatResult> onResult,
                           IntConsumer onProgress,
                           Runnable onComplete) {
        if (requests == null || service == null) {
            throw new IllegalArgumentException("Requests and service cannot be null.");
        }
        if (!running.compareAndSet(false, true)) {
            throw new IllegalStateException("An analysis batch is already running.");
        }

        List<AnalysisRequest> safeRequests = new ArrayList<>(requests);
        if (safeRequests.isEmpty()) {
            running.set(false);
            dispatch(onProgress, 100);
            dispatch(onComplete);
            return;
        }

        Thread coordinator = new Thread(() -> {
            CompletionService<ThreatResult> completion =
                    new ExecutorCompletionService<>(workers);
            try {
                for (AnalysisRequest request : safeRequests) {
                    completion.submit(() -> service.analyze(request));
                }

                int completed = 0;
                while (completed < safeRequests.size()) {
                    Future<ThreatResult> future = completion.take();
                    ThreatResult result;
                    try {
                        result = future.get();
                    } catch (ExecutionException ex) {
                        // A task that unexpectedly fails must never be labelled safe.
                        result = ThreatResult.notVerified("", null,
                                "Unexpected worker failure: " + ex.getCause());
                    }
                    completed++;
                    if (onResult != null) {
                        ThreatResult finalResult = result;
                        SwingUtilities.invokeLater(() -> onResult.accept(finalResult));
                    }
                    if (onProgress != null) {
                        int percent = (completed * 100) / safeRequests.size();
                        dispatch(onProgress, percent);
                    }
                }
            } catch (InterruptedException ex) {
                Thread.currentThread().interrupt();
            } finally {
                running.set(false);
                dispatch(onComplete);
            }
        }, "analysis-coordinator");

        coordinator.setDaemon(true);
        coordinator.start();
    }

    private void dispatch(IntConsumer callback, int value) {
        if (callback != null) {
            SwingUtilities.invokeLater(() -> callback.accept(value));
        }
    }

    private void dispatch(Runnable callback) {
        if (callback != null) {
            SwingUtilities.invokeLater(callback);
        }
    }

    @Override
    public void close() {
        workers.shutdown();
        try {
            if (!workers.awaitTermination(3, TimeUnit.SECONDS)) {
                workers.shutdownNow();
            }
        } catch (InterruptedException ex) {
            workers.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
