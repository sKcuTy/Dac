package com.threatdetector.service;

import com.threatdetector.model.AnalysisRequest;
import com.threatdetector.model.InputType;
import com.threatdetector.model.ThreatResult;

/*
 * Integration contract:
 * Member 2 must provide UrlAnalyzer with:
 *     public ThreatResult analyze(String url)
 * Member 3 must provide MessageAnalyzer with:
 *     public ThreatResult analyze(String message)
 *
 * If their method/class names differ, change only the two calls below.
 */
public class ThreatDetectionService {
    private final UrlAnalyzer urlAnalyzer;
    private final MessageAnalyzer messageAnalyzer;

    public ThreatDetectionService(UrlAnalyzer urlAnalyzer,
                                  MessageAnalyzer messageAnalyzer) {
        this.urlAnalyzer = urlAnalyzer;
        this.messageAnalyzer = messageAnalyzer;
    }

    public ThreatResult analyze(AnalysisRequest request) {
        if (request == null || request.getInput() == null ||
                request.getInput().trim().isEmpty() || request.getInputType() == null) {
            String value = request == null ? "" : request.getInput();
            InputType type = request == null ? null : request.getInputType();
            return type == null
                    ? new ThreatResult(value, null,
                        com.threatdetector.model.RiskLevel.NOT_VERIFIED, 0,
                        "Missing input or input type.", "Not Verified")
                    : ThreatResult.notVerified(value, type, "Input is empty or invalid.");
        }

        try {
            if (request.getInputType() == InputType.URL) {
                return urlAnalyzer.analyze(request.getInput());
            }
            if (request.getInputType() == InputType.MESSAGE) {
                return messageAnalyzer.analyze(request.getInput());
            }
            return ThreatResult.notVerified(request.getInput(), request.getInputType(),
                    "Unsupported input type.");
        } catch (Exception ex) {
            return ThreatResult.notVerified(request.getInput(), request.getInputType(),
                    "Analysis error: " + safeMessage(ex));
        }
    }

    private String safeMessage(Exception ex) {
        return ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
    }
}
