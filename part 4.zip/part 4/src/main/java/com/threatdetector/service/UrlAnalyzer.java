
package com.threatdetector.service;

import com.threatdetector.model.*;

public class UrlAnalyzer {

    public ThreatResult analyze(String url) {

        if (url == null || url.trim().isEmpty()) {
            return ThreatResult.notVerified(
                url, InputType.URL, "URL vide"
            );
        }

        return new ThreatResult(
            url,
            InputType.URL,
            RiskLevel.LOW,
            5,
            "Test URL effectué",
            "Completed"
        );
    }
}
