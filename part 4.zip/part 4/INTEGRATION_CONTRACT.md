# Member 4 – Integration contract

## Packages
Use the package names in the source tree:
- `com.threatdetector.model`
- `com.threatdetector.service`
- `com.threatdetector.concurrency`

## Required methods from teammates

Member 2 (URL):
```java
package com.threatdetector.service;
import com.threatdetector.model.ThreatResult;

public class UrlAnalyzer {
    public ThreatResult analyze(String url) { ... }
}
```

Member 3 (message):
```java
package com.threatdetector.service;
import com.threatdetector.model.ThreatResult;

public class MessageAnalyzer {
    public ThreatResult analyze(String message) { ... }
}
```

Both analyzers should return a `ThreatResult`. For invalid/unprocessable inputs, return
`ThreatResult.notVerified(input, InputType.URL or InputType.MESSAGE, reason)`.
Do not return LOW when analysis failed.

## How to use from the GUI (Member 1)

```java
AnalysisManager manager = new AnalysisManager(4);
ThreatDetectionService service =
    new ThreatDetectionService(new UrlAnalyzer(), new MessageAnalyzer());

List<AnalysisRequest> requests = new ArrayList<>();
requests.add(new AnalysisRequest("https://example.com", InputType.URL));
requests.add(new AnalysisRequest("Your account is blocked", InputType.MESSAGE));

manager.analyzeAll(
    requests,
    service,
    result -> {
        // Add one result row to the Swing JTable model here.
    },
    percent -> progressBar.setValue(percent),
    () -> {
        // Enable Analyze button / show completion message.
    }
);
```

Create the manager once and reuse it. Call `manager.close()` when the window is closing.
The callbacks are delivered on Swing's Event Dispatch Thread, so they can safely update Swing
components directly. Do not call `analyzeAll` from a long-running UI operation.

## Important notes
- The pool size is configurable; `4` means up to four worker tasks at once.
- `AnalysisManager` rejects a second batch while one is already running.
- Individual analyzer exceptions are converted to `NOT_VERIFIED`.
- Progress is based on completed tasks, not elapsed time.
- The current implementation supports one batch at a time. Add cancellation only if required.
- If your teammates use different package names or method names, agree on one shared contract
  and update the imports/calls before merging.
