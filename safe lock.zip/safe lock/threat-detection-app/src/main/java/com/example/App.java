
package com.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

import java.net.URL;

public class App extends Application {

    @Override
    public void start(Stage stage) {

        WebView webView = new WebView();

        URL html = getClass().getResource(
            "/web/safe-check-desk.html"
        );

        if (html == null) {
            System.out.println("HTML FILE NOT FOUND!");
            return;
        }

        System.out.println("HTML FILE FOUND!");

        webView.getEngine().load(html.toExternalForm());

        Scene scene = new Scene(webView, 1100, 750);

        stage.setTitle("Safe Link - Threat Detection App");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
