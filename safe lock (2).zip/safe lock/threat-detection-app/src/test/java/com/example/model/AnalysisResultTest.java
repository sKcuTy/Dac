package com.example.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;

import java.util.List;
import org.junit.Test;

public class AnalysisResultTest {

    @Test
    public void acceptsBackendScoreAndReasons() {
        AnalysisResult result = new AnalysisResult(
                "https://example.com",
                "url",
                "done",
                "Suspicious",
                "MEDIUM",
                75.5,
                List.of("Backend reason"));

        assertEquals(Double.valueOf(75.5), result.riskScore());
        assertEquals(List.of("Backend reason"), result.reasons());
    }

    @Test
    public void allowsUnavailableScoreForCompletedResult() {
        AnalysisResult result = new AnalysisResult(
                "message",
                "message",
                "done",
                null,
                "NONE",
                null,
                List.of());

        assertNull(result.riskScore());
    }

    @Test
    public void rejectsScoreOutsideRange() {
        assertThrows(IllegalArgumentException.class, () -> new AnalysisResult(
                "https://example.com",
                "url",
                "done",
                null,
                "LOW",
                101.0,
                List.of()));
    }

    @Test
    public void rejectsScoreForIncompleteAnalysis() {
        assertThrows(IllegalArgumentException.class, () -> new AnalysisResult(
                "https://example.com",
                "url",
                "not_verified",
                null,
                "NONE",
                0.0,
                List.of()));
    }

    @Test
    public void incompleteAnalysisHasNoVerdictOrRiskLevel() {
        AnalysisResult result = new AnalysisResult(
                "https://example.com",
                "url",
                "not_verified",
                null,
                "NONE",
                null,
                List.of("Analyzer unavailable"));

        assertNull(result.riskScore());
        assertNull(result.apiVerdict());
    }
}
