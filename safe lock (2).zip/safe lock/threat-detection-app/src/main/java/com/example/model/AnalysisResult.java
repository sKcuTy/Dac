package com.example.model;

import java.util.List;
import java.util.Objects;

public record AnalysisResult(
        String input,
        String type,
        String status,
        String apiVerdict,
        String riskLevel,
        Double riskScore,
        List<String> reasons) {

    public AnalysisResult {
        Objects.requireNonNull(input, "input");
        Objects.requireNonNull(type, "type");
        Objects.requireNonNull(status, "status");
        Objects.requireNonNull(riskLevel, "riskLevel");
        reasons = List.copyOf(Objects.requireNonNull(reasons, "reasons"));

        if (riskScore != null
                && (!Double.isFinite(riskScore) || riskScore < 0 || riskScore > 100)) {
            throw new IllegalArgumentException("riskScore must be between 0 and 100");
        }
        if (!"done".equals(status) && riskScore != null) {
            throw new IllegalArgumentException("riskScore is only available for completed analyses");
        }
        if (!"done".equals(status) && (!"NONE".equals(riskLevel) || apiVerdict != null)) {
            throw new IllegalArgumentException(
                    "incomplete analyses cannot have a risk level or API verdict");
        }
    }
}
