package com.example.service;

import com.example.model.AnalysisResult;

@FunctionalInterface
public interface InputAnalyzer {
    AnalysisResult analyze(String input);
}
